"""
ⒸMeruem | 2026
Core modules for application infrastructure
"""