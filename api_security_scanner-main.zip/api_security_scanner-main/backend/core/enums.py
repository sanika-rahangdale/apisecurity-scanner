"""
Enums for scan test types, statuses, and severity levels.

Values are plain lowercase strings (str, Enum) so they serialize directly
to JSON matching the string literals the frontend expects
(see frontend/src/config/constants.ts - SCAN_TEST_TYPES, SCAN_STATUS, SEVERITY).
"""

from enum import Enum


class TestType(str, Enum):
    """
    Type of security test a scanner performs
    """
    RATE_LIMIT = "rate_limit"
    AUTH = "auth"
    SQLI = "sqli"
    IDOR = "idor"


class ScanStatus(str, Enum):
    """
    Result status of an individual test
    """
    VULNERABLE = "vulnerable"
    SAFE = "safe"
    ERROR = "error"


class Severity(str, Enum):
    """
    Severity level of a finding
    """
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"
