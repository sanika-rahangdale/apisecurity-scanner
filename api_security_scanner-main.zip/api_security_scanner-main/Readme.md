```
███████╗ ██████╗ █████╗ ███╗   ██╗███╗   ██╗███████╗██████╗
██╔════╝██╔════╝██╔══██╗████╗  ██║████╗  ██║██╔════╝██╔══██╗
███████╗██║     ███████║██╔██╗ ██║██╔██╗ ██║█████╗  ██████╔╝
╚════██║██║     ██╔══██║██║╚██╗██║██║╚██╗██║██╔══╝  ██╔══██╗
███████║╚██████╗██║  ██║██║ ╚████║██║ ╚████║███████╗██║  ██║
╚══════╝ ╚═════╝╚═╝  ╚═╝╚═╝  ╚═══╝╚═╝  ╚═══╝╚══════╝╚═╝  ╚═╝
```

Full-stack API vulnerability scanner targeting the OWASP API Security Top 10, with configurable scan modules and a React dashboard.

This project runs **locally**. You need Python, Node.js, and PostgreSQL installed on your machine.

## What It Does

- Scans REST APIs against OWASP API Security Top 10 vulnerability categories
- Tests for authentication bypass, injection flaws, IDOR, and rate limiting weaknesses
- SQLi, authentication, IDOR, and rate limit scanner modules with configurable payloads
- JWT auth with bcrypt password hashing and session management
- Scan history tracking with detailed vulnerability reports per endpoint
- Full React dashboard for configuring scans and reviewing results

---

## Prerequisites

- **Python** 3.11+ (check with `python3 --version`)
- **Node.js** 18+ (check with `node -v`)
- **PostgreSQL** 14+ installed and running locally
- **npm** (comes with Node.js)

---

## 1. Clone / Download the project

Make sure you know the exact folder you're working in — mismatched folders (e.g. installing dependencies in one copy of the project while opening a different copy in your editor) is a common source of confusing "module not found" errors.

```bash
cd path/to/api_security_scanner
```

---

## 2. Set up PostgreSQL

Create a database and user matching your `.env` (see step 3):

```bash
psql -U postgres
```

```sql
CREATE USER apiuser WITH PASSWORD 'apipass';
CREATE DATABASE apisecurity OWNER apiuser;
```

(Adjust the username/password/database name if you plan to use different values in your `.env`.)

---

## 3. Configure environment variables

Copy the example env file and fill in real values:

```bash
cp .env.example .env
```

Open `.env` and review/update:
- `SECRET_KEY` — set this to a long random string
- `POSTGRES_USER`, `POSTGRES_PASSWORD`, `POSTGRES_DB`, `POSTGRES_HOST`, `POSTGRES_PORT` — must match what you created in step 2
- `VITE_API_URL` — should point at the backend, e.g. `http://localhost:8000`

---

## 4. Run the backend (FastAPI)

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

- API will be available at: `http://localhost:8000`
- Interactive API docs (Swagger): `http://localhost:8000/docs`
- Health check: `http://localhost:8000/health`

Leave this terminal running.

---

## 5. Run the frontend (React + Vite)

Open a **new terminal**:

```bash
cd frontend
npm install
npm run dev
```

The frontend will start on `http://localhost:5173` (default Vite port) and connect to the backend using the `VITE_API_URL` set in your `.env`.

Visit **`http://localhost:5173`** to open the dashboard.

---

## Troubleshooting

**"Cannot find module 'react'" / hundreds of red errors in the editor**
This means `node_modules` wasn't installed (or was installed in the wrong folder). Confirm you're in the right project directory, then:
```bash
cd frontend
rm -rf node_modules package-lock.json
npm install
```
Afterward, reload your editor window (in VSCode: `Ctrl+Shift+P` → "Developer: Reload Window").

**Backend fails to start / database connection errors**
- Confirm PostgreSQL is running: `pg_isready`
- Confirm the values in `.env` match the database/user you created in step 2
- Confirm `DATABASE_URL` in `.env` is correctly formed

**Port already in use**
- Backend: change `BACKEND_PORT` in `.env` and the `--port` flag in the uvicorn command
- Frontend: Vite will automatically offer the next available port if `5173` is taken

---

## Project structure

```
api_security_scanner/
├── backend/          # FastAPI application
│   ├── main.py       # Entry point
│   ├── factory.py    # App factory
│   ├── config.py     # Settings (reads from .env)
│   ├── routes/        # API routes
│   ├── scanners/      # Security scan implementations
│   └── ...
├── frontend/         # React + TypeScript (Vite) application
│   └── src/
├── .env.example      # Environment variable template
└── package.json      # Root convenience scripts
```